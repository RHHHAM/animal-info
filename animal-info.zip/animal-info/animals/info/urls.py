from django.urls import path #path function
from . import views # . is shorthand for the current directory

# one urlpattern per line
urlpatterns = [
    path('family/<int:id>', views.families, name='family'),
    path('animals/', views.animals, name='animals'),
    path('animals/<int:id>', views.animal, name='animal'),
    path('song', views.song, name='song')
]
