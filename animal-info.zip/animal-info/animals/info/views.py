from django.shortcuts import render, redirect
from django.http import HttpResponse
from . models import Animal, Family
import random
data = {
	    "animals": [
	        {
	            "id" :1,
	            "name": "Dog",
	            "legs": 4,
	            "weight": 5.67,
	            "height":4.2,
	            "speed": 34,
	            "family": 2
	        },
	        {
	            "id": 2,
	            "name": "Domestic Cat",
	            "legs": 2,
	            "weight": 5.67,
	            "height":4.2,
	            "speed": 34,
	            "family": 1
	        },
	        {
	            "id": 3,
	            "name": "Panther",
	            "legs": 2,
	            "weight": 5.67,
	            "height":4.2,
	            "speed": 34,
	            "family": 1 
	        }
	    ],
	    "families": [
	        {
	            "id": 1,
	            "name": "Felidae"
	        },
	        {
	            "id": 2,
	            "name": "Caninae"
	        }
	    ]
	}

def animals(request): 
	context = {
		'page_title': 'Animals',
		'animal': Animal.objects.order_by("family").all(),
	}
	return render(request, 'animals.html', context)

def animal(request, id): 
	context = {
		'page_title': 'Animals',
		'animal': Animal.objects.filter(id = id).all(),
		'family': Animal.objects.get(id = id).family,
		'id': id
	}
	return render(request, 'animal.html', context)

def families(request, id):
	context = {
		'page_title': 'Families',
		'family': Family.objects.filter(id = id).all(),
		'animals': Animal.objects.filter(family = id).order_by("name").all(),
		'count' : Animal.objects.filter(family = id).count(),
		'id': id
	}
	return render(request, 'families.html', context)

def song(request):
	songs = ["https://www.youtube.com/embed/pWepfJ-8XU0", "https://www.youtube.com/embed/pZw9veQ76fo"]
	context = {
		'page_title': 'Songs',
		'song': random.choice(songs)
	}
	return render(request, 'song.html', context)
# Create your views here.

