from django.db import models
from django.core.files import File
import os
# Create your models here.

class Family(models.Model):

	class Meta:
		managed = False
		db_table = 'families'

	id = models.IntegerField(db_column = 'id', primary_key=True)
	name = models.CharField(db_column = 'name', max_length = 50)

class Animal(models.Model):

	class Meta:
		managed = False
		db_table = 'animals'

	id = models.AutoField(db_column = 'id', primary_key=True)
	name = models.CharField(db_column = 'name',max_length = 50)
	legs = models.IntegerField(db_column = 'legs')
	weight = models.FloatField(db_column = 'weight')
	height = models.FloatField(db_column = 'height')
	speed = models.FloatField(db_column = 'speed')
	#image = models.ImageField(upload_to='info/static/info', blank=True)
	image_url = models.URLField(db_column = 'image_url', blank=True)
	family = models.ForeignKey(Family, on_delete=models.CASCADE, db_column = 'family')


	def get_remote_image(self):
	    if self.image_url and not self.image_file:
	        result = urllib.urlretrieve(self.image_url)
	        print(result)
	        self.image_file.save(
	                os.path.basename(self.image_url),
	                File(open(result[0]))
	                )
	        self.save()

