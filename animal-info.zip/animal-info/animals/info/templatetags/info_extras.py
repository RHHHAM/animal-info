from django import template

register = template.Library()


@register.filter(name='int2str')
def to_str(value):
    """converts int to string"""
    return str(value)

@register.filter(name='str2str')
def addstr(arg1, arg2):
    """concatenate arg1 & arg2"""
    return str(arg1) + str(arg2)